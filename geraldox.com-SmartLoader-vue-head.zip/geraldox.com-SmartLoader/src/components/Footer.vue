<template>
  <footer>
    <p>Copyright &copy; 2023 GMAPDEV</p>
  </footer>
</template>

<script>
module.exports = {};
</script>

<style>
footer {
  max-width: 75rem;
  min-width: 200px;
  margin: auto;
  background: rgb(20, 19, 19);
  padding: 20px;
  text-align: center;
  color: rgb(158, 149, 137);
  font-size: 13px;
  width: 100%;
}

/* for mobile */
@media screen and (max-width: 650px) {
  footer {
    background: rgb(29, 27, 27);
    text-align: center;
    color: dodgerblue;
  }
}
</style>

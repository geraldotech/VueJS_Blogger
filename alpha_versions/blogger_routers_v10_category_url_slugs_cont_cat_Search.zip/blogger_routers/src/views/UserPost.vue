<template>
  <div class="blogger">
    <main>
      <article v-if="blog">
        <h1>{{ blog.title }}</h1>
        <p class="author">
          By:<span>{{ blog.author }}</span> | Posted on: {{ blog.data }} |
          <button data="print" onclick="print()">Print</button> | Category:
          <router-link :to="`/categories/${blog.category}`">{{
            blog.category
          }}</router-link>
        </p>

        <hr />
        <p class="blogger__article" v-html="blog.article"></p>
        <!--   render components -->
        <component :is="blog.component"></component>
      </article>
      <div v-else>
        <h4 class="notFound">Post Not Found, or was removed!</h4>
      </div>

      <div v-if="$route.params.slug == 'post-one'">
        <p>Hello post:one</p>
      </div>
    </main>
    <Sidebar />
  </div>
</template>
<script>
module.exports = {
  created() {
    this.posts();
    //console.log(this.$route); //currently
    //console.log(this.$router); //parametros e funcionalidades
  },
  data() {
    return {
      blog: {},
    };
  },
  components: {
    Android: httpVueLoader("../components/android-roo.vue"),
    Sunday: httpVueLoader("../components/Sunday.vue"),
    Sidebar: httpVueLoader("../components/Sidebar.vue"),
    Speedtest: httpVueLoader("../components/Speedtest.vue"),
  },
  methods: {
    async posts() {
      const req = await fetch("./src/db/data.json");
      const data = await req.json();
      //console.warn(data);
      this.blogPosts = data.blog.posts;
      //filtra a slug atual e atualiza
      const getBlogPost = this.blogPosts.find(
        (post) => post.slug == this.$route.params.slug && post.published
      );
      // console.log(`getBlogPost`, getBlogPost);
      this.blog = getBlogPost;
    },
  },
};
</script>
<style scoped>
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
main {
  padding: 10px;
  min-height: 50vh;
}

article {
  padding: 5px;
  text-align: justify;
}
.blogger__article {
  margin-top: 15px;
}
p.author {
  font-size: 14px;
  background: black;
  margin: 10px 0;
  padding: 5px 0;
}
div img {
  display: block;
  margin: 0 auto;
  max-width: 100%;
}
figure:has(figcaption) {
  text-align: center;
  color: white;
}
div:has(img) {
  margin: 10px 0;
}
h2 {
  padding: 10px 0;
}
h1 {
  font-size: 1.7rem;
}
ul {
  margin-top: 20px;
  padding-left: 15px;
}
h4.notFound {
  text-align: center;
}
button[data*="print"] {
  background: none;
  padding: 0px 15px;
  border: 1px solid dodgerblue;
  cursor: pointer;
  margin-bottom: 5px;
}

/* for desktop */
@media screen and (min-width: 600px) {
  .blogger {
    display: flex;
    padding: 50px;
  }
  .blogger main {
    flex: 1 0 75%;
  }
}
</style>
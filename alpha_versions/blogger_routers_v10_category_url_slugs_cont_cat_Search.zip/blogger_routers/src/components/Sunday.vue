<template>
  <div>
    <p>Hello I am sunday component</p>
    <div>
      <img
        src="./src/assets/img/kevin-canlas-cFFEeHNZEqw-unsplash.jpg"
        alt=""
      />
    </div>
  </div>
</template>
<script>
module.exports = {};
</script>
<style scoped>
p {
  color: blueviolet;
  font-size: 2rem;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
</style>

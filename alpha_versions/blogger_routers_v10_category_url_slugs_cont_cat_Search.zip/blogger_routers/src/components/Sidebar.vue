<template>
  <div class="sidebar">
    <h2>Sidebar</h2>
    <p class="search"><Search /></p>
    <hr />
    <p>
      Lorem ipsum dolor, sit amet consectetur adipisicing elit. Aliquid,
      deleniti?
    </p>
    <ul>
      <li><a href="#">Home</a></li>
      <li><a href="#">Page</a></li>
    </ul>
    <div>
      <img
        src="https://images.unsplash.com/photo-1536412597336-ade7b523ecfc?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80"
        alt=""
      />
    </div>
  </div>
</template>
<script>
module.exports = {
  data() {
    return {};
  },
  components: {
    Search: httpVueLoader("../components/Search.vue"),
  },
};
</script>
<style scoped>
.sidebar {
  padding: 2px;
  text-align: justify;
}
h2 {
  text-align: center;
}

.sidebar div img {
  width: 100%;
}
.search {
  text-align: center;
  margin-bottom: 20px;
}
.search p {
  color: rgb(10, 184, 68);
}
/* mobile */
@media screen and (max-width: 600px) {
  .sidebar div img {
    display: block;
    max-width: 60%;
    margin: auto;
  }
  .sidebar ul {
    margin-left: 40px;
  }
}
</style>

<template>
  <div class="search">
    <form @submit.prevent="search">
      <input name="" type="text" v-model="info" placeholder="Search box" />
      <input type="submit" value="Search" />
    </form>

    <p>{{ res }}</p>
    <ul v-for="items in results" :key="items.id">
      <li>
        <router-link
          :to="{
            name: 'threads',
            params: { category: items.category, slug: items.slug },
          }"
        >
          {{ items.title }}</router-link
        >
      </li>
    </ul>
  </div>
</template>
<script>
module.exports = {
  created() {
    this.posts();
  },
  data() {
    return {
      info: "",
      blog: [],
      results: "",
      res: "",
    };
  },
  methods: {
    async posts() {
      const req = await fetch("./src/db/data.json");
      const res = await req.json();
      console.log(res);
      this.blog = res.blog.posts;
    },
    search: function () {
      //faz a busca, compada os valores em maiusculas
      const busca = this.blog.filter((val) =>
        val.title.toUpperCase().includes(this.info.toUpperCase())
      );
      console.warn(busca.length ? busca : "404");

      this.results = busca;
      //busca.length ? (this.results = busca) : this.not == true;
      if (!this.results.length) {
        this.res = "We are sorry, 404";
      } else {
        this.res = `Showing ${this.results.length} results for "${this.info}"`;
      }
    },
  },
  watch: {},
};
</script>
/* global styles for this component */
<style scoped>
input[type="text"] {
}
.search {
  border-bottom: 1px solid red;
  padding: 5px;
  text-align: center;
}
.search {
  text-align: center;
  margin-bottom: 20px;
}
.search p {
  color: rgb(10, 184, 68);
  margin-top: 5px;
}
.search li {
  text-align: left;
  list-style-type: square;
}

.search li a {
  color: rgb(207, 40, 199);
  font-size: 1rem;
}
.search li {
  border-bottom: none;
}
</style>


<template>
  <div class="list-all">
    <section class="threads">
      <p class="search"><Search /></p>

      <section class="map">
        <h1><router-link to="/mapa">Mapa de categorias</router-link></h1>

        <label>Selecionar:</label>
        <select v-model="select" @change="changeRoute($event)">
          <option
            v-for="(itens, ind) in categorias"
            :key="itens.id"
            :value="ind"
          >
            {{ ind.toUpperCase() }} - {{ itens }}
          </option>
        </select>
      </section>

      <h1>Threads</h1>
      <ul v-for="artigos in opt" :key="artigos.slug">
        <li>
          <router-link
            :to="{
              name: 'threads',
              params: { category: artigos.category, slug: artigos.slug },
            }"
          >
            {{ artigos.title }}</router-link
          >
          | Category:
          <!-- categories router page -->
          <router-link class="cats" :to="`/categories/${artigos.category}`">{{
            artigos.category ? artigos.category.toUpperCase() : "UNCATEGORIZED"
          }}</router-link>
          <time>{{ artigos.data }}</time>
          <!--    <p v-html="artigos.article ? artigos.article.substr(0, 35) : ''"></p> -->
          <div></div>
        </li>
      </ul>
    </section>
  </div>
</template>

<script>
module.exports = {
  created() {
    this.posts();
  },
  components: {
    Sidebar: httpVueLoader("../components/Sidebar.vue"),
    Search: httpVueLoader("../components/Search.vue"),
  },
  data() {
    return {
      opt: "",
      categorias: {},
      blogPostsProp: [],
      select: "",
    };
  },
  methods: {
    async posts() {
      const req = await fetch("./src/db/data.json");
      const res = await req.json();
      //filter post published
      const blogPosts = res.blog.posts.filter((posts) => posts.published);
      //console.log(publicados);
      //reverse render posts mais novos on top
      this.opt = blogPosts.reverse();
      this.blogPostsProp = blogPosts;
      //limitador, remember que is ele estão invertidos
      //this.opt.splice(6, 0);

      //start categorias categorias only
      const getCatego = this.opt.map((val) => val.category);

      //filter remove duplicado e undefined itens
      const filtra = getCatego.filter(
        (val, ind) => getCatego.indexOf(val) == ind && val != undefined
      );
      //cat recebe categorias sem duplicados and ordenar sort()
      //this.categorias = filtra.sort();

      //contar n de categories values + ordenar com sort()
      const counter = getCatego
        .sort()
        .reduce((cont, item) => ((cont[item] = cont[item] + 1 || 1), cont), {});
      //recebe o contador unique + contador
      this.categorias = counter;
    },
    changeRoute(e) {
      this.$router.push("/categories/" + e.target.value);
    },
  },
};
</script>
<style scoped>
* {
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
div,
ul {
  margin-top: 10px;
  padding-left: 5px;
}
h1 {
  margin-top: 20px;
}

.threads a {
  text-decoration: none;
  color: #3aa4ff;
  font-size: 1.4rem;
  font-weight: bold;
}
h1 {
  font-size: 1.7rem;
}
.threads li {
  border-bottom: 2px solid green;
  margin: 20px 0;
}

.threads .cats {
  font-size: 0.7rem;
  color: rgb(131, 4, 170);
}

.sidebar img {
  width: 100%;
}

.map p {
  padding: 10px 0;
}

time {
  font-family: sans-serif;
  display: block;
}
time::before {
  content: "Date: ";
}

select {
  cursor: pointer;
}

@media screen and (min-width: 650px) {
  .list-all {
    display: flex;
    width: 80%;
    padding: 50px 0;
    margin: 0 auto;
  }
  .threads {
    flex: 1 0 80%;
  }
  .sidebar {
    width: 20%;
  }
}
</style>

<template>
  <p>Footer.vue</p>
</template>

<script>
module.exports = {};
</script>

<style>
</style>
<template>
  <div>
    <hr />

    <h1>List articles</h1>
    <ul v-for="artigos in opt" :key="artigos.slug">
      <li>
        <router-link :to="`/blog/${artigos.slug}`">{{
          artigos.title
        }}</router-link>
      </li>
    </ul>
  </div>
</template>

<script>
module.exports = {
  created() {
    this.posts();
  },
  data() {
    return {
      opt: "",
    };
  },
  components: {
    Menua: httpVueLoader("./Menu.vue"),
  },
  methods: {
    async posts() {
      const req = await fetch("./src/data.json");
      const res = await req.json();
      console.log(res);
      this.opt = res.blog.posts;
    },
  },
};
</script>
<style scoped>
div,
ul {
  margin-top: 10px;
}
</style>

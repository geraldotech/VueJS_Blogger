<template>
  <div>
    <nav>
      <li>
        <router-link to="/">Home</router-link>
      </li>
      <li>
        <router-link to="/youtube">Youtube</router-link>
      </li>
      <li>
        <router-link :to="{name: 'Blog Posts'}">Blog</router-link>
      </li>      
    </nav>
     <hr />
   <section>
      <router-view></router-view>
    <!--  router named -->
   <router-view name="yt" class="named-views"></router-view>
   </section>
    <Foot>
  </div>
</template>

<script>
module.exports = {
  data() {
    return {};
  },
  components: {
    Foot: httpVueLoader("./components/Footer.vue"),
  },
  methods: {},
};
</script>
<style>
:root {
  --maxw: 75rem;
}
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
body {
  min-width: 320px;
  max-width: var(--maxw);
  margin: 0 auto;
  padding: 10px;
  min-height: 100vh;
}
nav {
  display: flex;
  max-width: var(--maxw);
  justify-content: space-evenly;
  width: 100%;
  padding: 15px 5px;
}
nav li {
  list-style: none;
}

nav a {
  text-decoration: none;
  background: rgb(29, 27, 27);
  padding: 5px 20px;
  border-radius: 5px;
}
section {
  padding: 0px 10px;
  max-width: var(--maxw);
}
/* class named views */
.named-views {
  text-align: center;
  padding: 10px 0;
  border-bottom: 1px solid red;
}

.block {
  font-size: 1.2rem;
  text-align: center;
  min-height: 80vh;
  margin-top: 20px;
}

/* for desktop */
@media screen and (min-width: 650px) {
  section {
  }
}
</style>

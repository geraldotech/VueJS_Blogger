<template>
  <div>
    <h2>Hi I'm a Android Component</h2>
    <p>Melhores apps para o Android com Root Access</p>
    <ul>
      <li>
        Adway -
        <a href="https://f-droid.org/packages/org.adaway/" target="_blank"
          >Download</a
        >
      </li>
    </ul>
    <div><img src="https://adaway.org/assets/img/adaway.png" alt="root" /></div>
  </div>
</template>
<script>
module.exports = {};
</script>
<style scoped>
h2 {
  color: rgb(7, 112, 24);
  padding: 5px;
  text-align: center;
}
ul li {
  color: white;
}
</style>

<template>
  <div class="list-all">
    <section class="threads">
      <h1>Threads</h1>
      <ul v-for="artigos in opt" :key="artigos.slug">
        <li>
          <router-link :to="`/blog/${artigos.slug}`">{{
            artigos.title
          }}</router-link>
          | {{ artigos.data }}
          <div></div>
        </li>
      </ul>
    </section>
    <Sidebar />
  </div>
</template>

<script>
module.exports = {
  created() {
    this.posts();
  },
  components: {
    Sidebar: httpVueLoader("../components/Sidebar.vue"),
  },
  data() {
    return {
      opt: "",
    };
  },
  methods: {
    async posts() {
      const req = await fetch("./src/db/data.json");
      const res = await req.json();
      //filter post published
      const publicados = res.blog.posts.filter((posts) => posts.published);
      //console.log(publicados);
      //reverse render posts mais novos on top
      this.opt = publicados.reverse();
      //limitador
      //this.opt.splice(0, 2);
    },
  },
};
</script>
<style scoped>
div,
ul {
  margin-top: 10px;
  padding-left: 5px;
}
h1 {
  margin-top: 20px;
}

.threads {
  margin: 0 15px;
}
.threads a {
  text-decoration: none;
  color: #3aa4ff;
  font-size: 1.4rem;
  font-weight: bold;
}
h1 {
  font-size: 1.7rem;
}
.threads li {
  border-bottom: 2px solid green;
  margin: 20px 0;
}

.sidebar img {
  width: 100%;
}

@media screen and (min-width: 650px) {
  .list-all {
    display: flex;
    width: 80%;
    padding: 50px 0;
    margin: 0 auto;
  }
  .threads {
    flex: 1 0 80%;
  }
  .sidebar {
    width: 20%;
  }
}
</style>

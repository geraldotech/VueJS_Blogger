<template>
  <div class="block">
    <h2>Home Page</h2>
  </div>
</template>

<script>
module.exports = {};
</script>

<style>
footer {
  /* bottom: 2;
  position: absolute;
  left: 0;
  right: 0;
  max-width: 75rem; */
}
</style>
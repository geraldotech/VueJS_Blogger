const Home = { template: `<p>Home Page</p>` };
const youtube = {
  template: `<div class="block">
  <p>Youtube > Youtube Page</p>
  <router-link :to="{name:'r1'}">Music</router-link>
  <router-link :to="{name:'r2'}">Films</router-link>
<router-view></router-view>
  </div>
`,
};
const home2 = {
  template: `<p>VueJS Named Views from String </p>`,
};

const musica = {
  template: `<p>Content musicas </p>`,
};
const filmes = {
  template: `<p>Content filmes  {{$route.name}}</p>`,
};

const routes = [
  {
    path: "/",
    components: { default: httpVueLoader("./src/views/Home.vue"), yt: home2 },
  },
  {
    path: "/youtube",
    component: youtube,
    children: [
      { path: "music", name: "r1", component: musica },
      { path: "movie", name: "r2", component: filmes },
    ],
  },
  {
    path: "/footer",
    name: `footer`,
    component: httpVueLoader("./src/Footer.vue"),
  },
  {
    path: "/blog",
    component: httpVueLoader("./src/views/Blog.vue"),
  },
  {
    path: "/blog/:slug",
    component: httpVueLoader("./src/views/UserPost.vue"),
  },
];

const router = new VueRouter({
  routes,
});

const vm = new Vue({
  data: {
    opt: "",
  },
  el: "#app",
  router,
  template: `<App></App>`, //component pai
  components: {
    App: httpVueLoader("./src/App.vue"),
  },
});

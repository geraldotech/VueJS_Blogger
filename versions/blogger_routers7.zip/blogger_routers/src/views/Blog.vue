<template>
  <div>
    <hr />
    <h1>Threads</h1>
    <ul v-for="artigos in opt" :key="artigos.slug">
      <li>
        <router-link :to="`/blog/${artigos.slug}`">{{
          artigos.title
        }}</router-link>
        | {{ artigos.data }}
        <div></div>
      </li>
    </ul>
  </div>
</template>

<script>
module.exports = {
  created() {
    this.posts();
  },
  data() {
    return {
      opt: "",
    };
  },
  methods: {
    async posts() {
      const req = await fetch("./src/db/data.json");
      const res = await req.json();
      //filter post published
      const publicados = res.blog.posts.filter((posts) => posts.published);
      //console.log(publicados);
      //reverse render posts mais novos on top
      this.opt = publicados.reverse();
      //limitador
      //this.opt.splice(0, 2);
    },
  },
};
</script>
<style scoped>
div,
ul {
  margin-top: 10px;
  padding-left: 20px;
}
h1 {
  margin-top: 20px;
}
a {
  text-decoration: none;
  color: #3aa4ff;
  font-size: 1.4rem;

  font-weight: bold;
}
h1 {
  font-size: 1.7rem;
}
li {
  border-bottom: 2px solid green;
  margin: 20px 0;
}
</style>

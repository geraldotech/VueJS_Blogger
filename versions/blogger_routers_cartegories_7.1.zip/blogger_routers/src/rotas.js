const Home = { template: `<p>Home Page</p>` };
const youtube = {
  template: `<div style="text-align:center">
  <p>Youtube > Youtube Page</p>
  <router-link :to="{name:'r1'}">Music</router-link>
  <router-link :to="{name:'r2'}">Films</router-link>
<router-view></router-view>
  </div>
`,
};
const vuejs = {
  template: `<p>My VueJS Named Views </p>`,
};

const musica = {
  template: `<p>Content musicas </p>`,
};
const filmes = {
  template: `<p>Content filmes  {{$route.name}}</p>`,
};

const routes = [
  { path: "/", components: { default: Home, yt: vuejs } },
  {
    path: "/youtube",
    component: youtube,
    children: [
      { path: "music", name: "r1", component: musica },
      { path: "movie", name: "r2", component: filmes },
    ],
  },
  {
    path: "/footer",
    name: `footer`,
    component: httpVueLoader("./src/Footer.vue"),
  },
  {
    path: "/blog",
    component: httpVueLoader("./src/views/Blog.vue"),
  },
  {
    path: "/blog/:slug",
    component: httpVueLoader("./src/views/UserPost.vue"),
    name: "blogPosts",
  },
  {
    path: "/categories",
    component: httpVueLoader("./src/views/Categories.vue"),
  },
  {
    path: "/categories/:category",
    component: httpVueLoader("./src/views/Categories.vue"),
  },
  {
    path: "/categories/threads/:category",
    component: httpVueLoader("./src/views/Lista.vue"),
  },
  {
    path: "/blog/:slug/:pathMatch(.*)*",
    name: "NotFound",
    component: filmes,
  },
];

const router = new VueRouter({
  routes,
});

export default router;

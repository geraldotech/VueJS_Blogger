<template>
  <div>
    <main>
      <article v-if="blog">
        <p>{{ $route.params }}</p>
        <p>{{ $route.name }}</p>
        <h1>{{ blog.title }}</h1>
        <p class="author">
          By:<span>{{ blog.author }}</span> | Posted on: {{ blog.data }} |
        </p>
        <button data="print" onclick="print()">Print</button>

        <hr />
        <p v-html="blog.article"></p>
        <!--   render components -->
        <component :is="blog.component"></component>
      </article>
      <div v-else>
        <h4 class="notFound">Post Not Found, or was removed!</h4>
      </div>

      <div v-if="$route.params.slug == 'post-one'">
        <p>Hello post:one</p>
      </div>
    </main>
  </div>
</template>
<script>
module.exports = {
  data() {
    return {
      blog: {},
      blogPosts: {},
    };
  },
  components: {
    Android: httpVueLoader("../components/android-roo.vue"),
    Sunday: httpVueLoader("../components/Sunday.vue"),
  },
  created() {
    this.posts();
    console.log(this.$route);
    //console.log(this.$router); //parametros e funcionalidades
  },
  methods: {
    async posts() {
      const req = await fetch("./src/db/data.json");
      const data = await req.json();
      //console.warn(data);
      this.blogPosts = data.blog.posts;
      //filtra a slug atual e atualiza
      const getBlogPost = this.blogPosts.find(
        (post) => this.$route.params.slug == post.slug
      );
      // console.log(`getBlogPost`, getBlogPost);
      this.blog = getBlogPost;
      console.log(getBlogPost);
    },
  },
};
</script>
<style scoped>
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
main {
  padding: 10px;
}
article {
  color: dodgerblue;
  padding: 5px;
  text-align: justify;
}
p.author {
  font-size: 14px;
  background: black;
  margin: 10px 0;
}
img {
  display: block;
  margin: 0 auto;
  width: 100%;
  max-width: 50%;
}
figure:has(figcaption) {
  text-align: center;
  color: white;
}
div:has(img) {
  margin: 10px 0;
}
h2 {
  padding: 10px 0;
}
h1 {
  font-size: 1.7rem;
}
ul {
  margin-top: 20px;
  padding-left: 15px;
}
h4.notFound {
  text-align: center;
}
button[data*="print"] {
  background: none;
  padding: 0px 15px;
  border: 1px solid dodgerblue;
  cursor: pointer;
  margin-bottom: 5px;
}
</style>
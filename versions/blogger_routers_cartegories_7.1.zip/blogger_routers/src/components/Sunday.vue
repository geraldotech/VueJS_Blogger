<template>
  <div>
    <p>Hello I am sunday component</p>
    <img src="https://via.placeholder.com/200x50" alt="" />
  </div>
</template>
<script>
module.exports = {};
</script>
<style scoped>
p {
  color: blueviolet;
  font-size: 2rem;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
</style>

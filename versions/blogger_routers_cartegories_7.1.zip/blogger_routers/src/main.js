import router from "./rotas.js";

const vm = new Vue({
  data: {
    opt: "",
  },
  el: "#app",
  router,
  template: `<App></App>`, //component pai
  components: {
    App: httpVueLoader("./src/App.vue"),
  },
});

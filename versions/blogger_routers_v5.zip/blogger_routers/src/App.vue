<template>
  <div>
    <nav>
      <li>
        <router-link to="/">Home</router-link>
      </li>
      <li>
        <router-link to="/youtube">Youtube</router-link>
      </li>
      <li>
        <router-link to="/blog">Blog</router-link>
      </li>      
    </nav>
   <section>
      <router-view></router-view>
    <!--  router named -->
    <router-view name="yt"></router-view>
   </section>
    <Foot>
  </div>
</template>

<script>
module.exports = {
  data() {
    return {};
  },
  components: {
    Foot: httpVueLoader("./components/Footer.vue"),
  },
  methods: {},
};
</script>
<style scoped>
:root {
  --maxw: 900px;
}
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
body {
  min-width: 320px;
  max-width: 50rem;
  margin: 0 auto;
  padding: 10px;
}
nav {
  display: flex;
  max-width: var(--maxw);
  justify-content: space-around;
  width: 100%;
  padding: 15px 5px;
}
nav li {
  list-style: none;
}

nav a {
  text-decoration: none;
}
section {
  padding: 10px;
  max-width: var(--maxw);
}
</style>

<template>
  <div>
    <hr />
    <h1>Articles</h1>
    <ul v-for="artigos in opt" :key="artigos.slug">
      <li>
        <router-link :to="`/blog/${artigos.slug}`">{{
          artigos.title
        }}</router-link>
        | {{ artigos.data }}
      </li>
    </ul>
  </div>
</template>

<script>
module.exports = {
  created() {
    this.posts();
  },
  data() {
    return {
      opt: "",
    };
  },
  methods: {
    async posts() {
      const req = await fetch("./src/db/data.json");
      const res = await req.json();
      console.log(`res`, res);
      //reverse render posts mais novos on top
      this.opt = res.blog.posts.reverse();
      //limitador
      //this.opt.splice(0, 2);
    },
  },
};
</script>
<style scoped>
div,
ul {
  margin-top: 10px;
  padding-left: 20px;
}
h1 {
  margin-top: 20px;
}
</style>

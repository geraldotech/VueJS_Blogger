<template>
  <div>
    <nav>
      <li>
        <router-link to="/">Home</router-link>
      </li>
      <li>
        <router-link to="/youtube">Youtube</router-link>
      </li>
      <li>
        <router-link to="/blog">Blog</router-link>
      </li>
    </nav>

    <router-view></router-view>
  </div>
</template>

<script>
module.exports = {
  data() {
    return {
      opt: "",
    };
  },
  components: {},
  methods: {},
};
</script>
<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
body {
  min-width: 320px;
  max-width: 50rem;
  margin: 0 auto;
  padding: 10px;
}
nav {
  display: flex;
  max-width: 520px;
  justify-content: space-around;
  width: 100%;
  padding: 15px 5px;
}
li {
  list-style: none;
}
</style>

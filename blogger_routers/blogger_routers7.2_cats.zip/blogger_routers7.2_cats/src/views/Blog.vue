<template>
  <div>
    <hr />
    <section class="cat">
      <h1>Map: Categorias</h1>
      <li><router-link to="/mapa">Mapa de categorias</router-link></li>
      <p>{{ categorias }}</p>
      <label for="op">Selecionar:</label>
      <select id="op" v-model="select" @change="changeRoute($event)">
        <option v-for="itens in categorias" :key="itens" :value="itens">
          {{ itens }}
        </option>
      </select>

      <router-view></router-view>
    </section>
    <h1>Threads</h1>

    <ul v-for="artigos in opt" :key="artigos.slug">
      <li>
        <router-link :to="`/blog/${artigos.slug}`">{{
          artigos.title
        }}</router-link>
        | {{ artigos.data }}
        <p>
          Categoria:
          {{ artigos.category ? artigos.category : "Undefined" }}
        </p>
        <div></div>
      </li>
    </ul>
  </div>
</template>

<script>
module.exports = {
  created() {
    this.posts();
  },
  data() {
    return {
      opt: "",
      categorias: {},
      blogPosts: [],
      select: "",
    };
  },
  methods: {
    async posts() {
      const req = await fetch("./src/db/data.json");
      const res = await req.json();
      //filter post published
      const blogPosts = res.blog.posts.filter((posts) => posts.published);
      // console.log(blogPosts);
      //reverse render posts mais novos on top
      this.opt = blogPosts.reverse();
      //limitador
      //this.opt.splice(0, 2);
      //console.dir(blogPosts);

      //start categorias categorias only

      const getCatego = this.opt.map((val) => val.category);
      console.warn(getCatego);
      //filter remove duplicado e undefined itens
      const filtra = getCatego.filter(
        (val, ind) => getCatego.indexOf(val) == ind && val != undefined
      );
      console.log(`filtro ok`, filtra);
      this.categorias = filtra.sort();
    },
    changeRoute(e) {
      console.log(e);
      this.$router.push("/categories/" + e.target.value);
    },
  },
};
</script>
<style scoped>
div,
ul {
  margin-top: 10px;
  padding-left: 20px;
}
h1 {
  margin-top: 20px;
}
a {
  text-decoration: none;
  color: #3aa4ff;
  font-size: 1.4rem;

  font-weight: bold;
}
h1 {
  font-size: 1.7rem;
}
li {
  border-bottom: 2px solid green;
  margin: 20px 0;
}
section.cat a {
  font-size: 1rem;
}
</style>

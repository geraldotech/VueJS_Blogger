<template>
  <div>
    <h1>Category: {{ $route.params.category }}</h1>
    <h3><router-link to="/blog">Voltar para Blog</router-link></h3>
    <ul v-for="artigos in opt" :key="artigos.slug">
      <li>
        <router-link :to="`/blog/${artigos.slug}`">{{
          artigos.slug
        }}</router-link>
        <div></div>
      </li>
    </ul>
    <router-view></router-view>
  </div>
</template>

<script>
module.exports = {
  created() {
    this.posts();
    console.log(this.$route);
  },
  data() {
    return {
      opt: "",
    };
  },
  methods: {
    async posts() {
      const req = await fetch("./src/db/data.json");
      const res = await req.json();
      //filter post published
      this.blogPosts = res.blog.posts;
      const getBlogPost = this.blogPosts.filter(
        (post) => this.$route.params.category == post.category
      );
      //console.log(publicados);
      //reverse render posts mais novos on top
      this.opt = getBlogPost;
      //limitador
      //this.opt.splice(0, 2);
      console.log(`teee`);
    },
  },
};
</script>
<style scoped>
div,
ul {
  margin-top: 10px;
  padding-left: 20px;
}
h1 {
  margin-top: 20px;
}
a {
  text-decoration: none;
  color: #3aa4ff;
  font-size: 1.4rem;

  font-weight: bold;
}
h1 {
  font-size: 1.7rem;
}
li {
  border-bottom: 2px solid green;
  margin: 20px 0;
}
</style>

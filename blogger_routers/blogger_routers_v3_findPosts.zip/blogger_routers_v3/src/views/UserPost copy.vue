<template>
  <div>
    <main>
      <div v-for="todos in results" :key="todos.id">
        <h1>{{ todos.title }}</h1>
        <p class="author">
          By:<span>{{ todos.author }}</span> | Posted on: {{ todos.data }}
        </p>
        <hr />
        <article>
          <p v-html="todos.article"></p>
        </article>
      </div>
      <div style="min-width: 100%; height: 5px; background: coral"></div>
      <div>Post {{ $route.params }}</div>
      <div>Post.id {{ $route.params.slug }}</div>
      <div v-if="$route.params.slug == 'post-one'">
        <p>contente one</p>
      </div>
    </main>
  </div>
</template>
<script>
module.exports = {
  created() {
    //console.log(this.$route); //currently
    //console.log(this.$router); //parametros e funcionalidades
  },
  data() {
    return {
      product: {},
      filtraPost: [],
      results: {},
    };
  },
  created() {
    this.posts();
    console.log(this.$route.params);
  },
  methods: {
    async posts() {
      const req = await fetch("./src/data.json");
      const data = await req.json();
      //console.warn(data);
      this.product = data.blog.posts;
      //filtra a slug atual e atualiza
      const filtered = this.product.filter(
        (item) => item.slug == this.$route.params.slug
      );
      console.log(`filtered`, filtered);
      this.results = filtered;
    },
  },
};
</script>
<style scoped>
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
main {
  margin-top: 50px;
  padding: 10px;
}
p {
  color: dodgerblue;
  padding: 5px;
  text-align: justify;
}
p.author {
  font-size: 14px;
  background: black;
  margin: 10px 0;
}
img {
  display: block;
  margin: 0 auto;
  width: 100%;
  max-width: 50%;
}
div:has(img) {
  margin: 10px 0;
}
</style>
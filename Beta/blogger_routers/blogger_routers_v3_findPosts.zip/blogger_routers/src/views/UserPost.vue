<template>
  <div>
    <main>
      <div>
        <article v-if="blog">
          <h1>{{ blog.title }}</h1>
          <p class="author">
            By:<span>{{ blog.author }}</span> | Posted on: {{ blog.data }}
          </p>
          <hr />
          <p v-html="blog.article"></p>
        </article>
        <div v-else>Not Found!</div>
      </div>

      <div v-if="$route.params.slug == 'post-one'">
        <p>Hello post:one</p>
      </div>
    </main>
  </div>
</template>
<script>
module.exports = {
  created() {
    //console.log(this.$route); //currently
    //console.log(this.$router); //parametros e funcionalidades
  },
  data() {
    return {
      blog: {},
    };
  },
  created() {
    this.posts();
    console.log(this.$route.params);
  },
  methods: {
    async posts() {
      const req = await fetch("./src/db/data.json");
      const data = await req.json();
      //console.warn(data);
      this.blogPosts = data.blog.posts;
      //filtra a slug atual e atualiza
      const getBlogPost = this.blogPosts.find(
        (item) => item.slug == this.$route.params.slug
      );
      console.log(`getBlogPost`, getBlogPost);
      this.blog = getBlogPost;
    },
  },
};
</script>
<style scoped>
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-family: Verdana, Geneva, Tahoma, sans-serif;
}
main {
  margin-top: 50px;
  padding: 10px;
}
p {
  color: dodgerblue;
  padding: 5px;
  text-align: justify;
}
p.author {
  font-size: 14px;
  background: black;
  margin: 10px 0;
}
img {
  display: block;
  margin: 0 auto;
  width: 100%;
  max-width: 50%;
}
figure:has(figcaption) {
  text-align: center;
  color: white;
}
div:has(img) {
  margin: 10px 0;
}
h2 {
  padding: 10px 0;
}
</style>
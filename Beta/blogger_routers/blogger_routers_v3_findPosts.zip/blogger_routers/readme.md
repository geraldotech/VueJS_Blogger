# Blog JSON

### Features

- v-html para renderizar html diretamento do json file
- v-if v-else caso encontra o

filter() requer v-for:

```js

 <div v-for="todos in results" :key="todos.id">
        <h1>{{ todos.title }}</h1>
        <p class="author">
          By:<span>{{ todos.author }}</span> | Posted on: {{ todos.data }}
        </p>

        <article>
          <p v-html="todos.article"></p>
        </article>
      </div>
```

find() não requer v-for, chamar por obj.item, v-if serve para evitar erros ao renderizar o que não foi encontrado chamando o v-else

```js
  <article v-if="blog">
          <h1>{{ blog.title }}</h1>
          <p class="author">
            By:<span>{{ blog.author }}</span> | Posted on: {{ blog.data }}
          </p>
          <hr />
          <p v-html="blog.article"></p>
          <div>Post {{ $route.params }}</div>
          <div>Post.id {{ $route.params.slug }}</div>
        </article>
         <div v-else>Not Found!</div>
```

- support v-if route-params
<div v-if="$route.params.slug == 'post-one'">
        <p>Hello post:one</p>
      </div>

- Get route.params

```js
<div>Post {{ $route.params }}</div>
<div>Post.slug {{ $route.params.slug }}</div>
```

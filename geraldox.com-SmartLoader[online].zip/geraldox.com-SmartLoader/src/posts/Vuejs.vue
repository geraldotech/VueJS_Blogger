<template>
  <div>
    <p>How check Vue Version ?</p>
    <code> console.log(Vue.version);</code>
    <p>
      <a href="../src/files/vue.global_3.2.41_dev.zip" download
        >VueJS 3.2.41 Dev</a
      >
    </p>
  </div>
</template>
<script>
module.exports = {};
</script>
<style scoped>
code {
  color: green;
}
</style>

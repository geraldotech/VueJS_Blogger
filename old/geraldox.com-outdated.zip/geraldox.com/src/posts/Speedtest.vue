<template>
  <div>
    <ul>
      <li>
        <a href="http://fisica.ufpr.br/kurumin/" target="_blank"
          >Index of /kurumin (ufpr.br)</a
        >
      </li>
      <li>
        <a
          href="http://download.adobe.com/pub/adobe/photoshop/win/cs2/Photoshop_CS2_tryout.zip"
          target="_blank"
          >PhotoshopCS2 - 329MB</a
        >
      </li>
      <li>
        <a
          href="https://gmapdev.s3.amazonaws.com/assets/youtube-revanced-v18.15.40-all.apk"
          >gmapdev.amazonaws.youtube-revanced - 97MB</a
        >
      </li>
    </ul>
  </div>
</template>

<script>
module.exports = {};
</script>

<style scoped>
ul li {
  margin: 10px 0;
}
</style>
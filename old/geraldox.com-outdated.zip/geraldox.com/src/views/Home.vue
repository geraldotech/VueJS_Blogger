<template>
  <div class="block">
    <h2>Home Page</h2>
  </div>
</template>

<script>
module.exports = {};
</script>

<style>
</style>
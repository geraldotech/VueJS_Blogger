<template>
  <div>
    <h2>IP Tools</h2>
    <ul>
      <li><a href="http://myip.ms/">Check DNS Propagation</a></li>
      <li><a href="http://whatsmydns.net">[WhatsMyDNS.NET]</a></li>
      <li>
        <a href="https://downforeveryoneorjustme.com/">Check Website status</a>
      </li>
      <li><a href="https://www.abongo.com">DNS Host Whois Tools</a></li>
      <li>
        <a
          href=" https://en.wikipedia.org/wiki/List_of_Internet_top-level_domains"
          >CList of Internet top-level domains</a
        >
      </li>
    </ul>

    <h2>DNS</h2>
    <h2>Google</h2>
    <code>
      <pre>
         8.8.8.8 
         8.8.4.4
      </pre>
    </code>

    <h2>Cloudflare</h2>
    <pre>
        1.1.1.1
        1.0.0.0
    </pre>

    <h2>Over TLS</h2>
    <pre>
        1dot1dot1dot1.cloudflare-dns.com
    </pre>

    <h2>OpenDNS</h2>
    <pre>
        208.67.222.222
        208.67.220.220
    </pre>

    <h2>Others</h2>
    <pre>family-filter-dns.cleanbrowsing.org</pre>
  </div>
</template>

<script>
module.exports = {};
</script>

<style>
</style>
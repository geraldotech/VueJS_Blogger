<template>
  <footer>
    <p>geraldoX.com - 2023</p>
  </footer>
</template>

<script>
module.exports = {};
</script>

<style scoped>
footer {
  margin-top: 100px;
  background: rgb(20, 19, 19);
  padding: 15px;
  text-align: center;
}
</style>